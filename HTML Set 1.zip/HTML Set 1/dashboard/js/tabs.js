$('.nav a').click(function (e) {
    $(this).tab('show');
  
  var tabContent = '#tabContent_' + this.id; 
  
  $('#tabContent_personal').hide();
  $('#tabContent_financial').hide();
  $(tabContent).show();
})